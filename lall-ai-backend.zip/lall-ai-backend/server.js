import express from "express";
import cors from "cors";
import rateLimit from "express-rate-limit";

const app = express();
const PORT = process.env.PORT || 3000;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const OPENAI_MODEL = process.env.OPENAI_MODEL || "gpt-6-astra";

app.disable("x-powered-by");
app.use(express.json({ limit: "20kb" }));

// For a public deployment, set ALLOWED_ORIGIN to your app's web origin if applicable.
// Native mobile apps may not send an Origin header.
const allowedOrigin = process.env.ALLOWED_ORIGIN;
app.use(cors({
  origin: (origin, callback) => {
    if (!allowedOrigin || !origin || origin === allowedOrigin) {
      return callback(null, true);
    }
    return callback(new Error("Origin tidak diizinkan"));
  }
}));

app.use("/chat", rateLimit({
  windowMs: 60 * 1000,
  limit: 20,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Terlalu banyak permintaan. Coba lagi sebentar." }
}));

app.get("/", (_req, res) => {
  res.json({ name: "LALL AI Backend", status: "online" });
});

app.get("/health", (_req, res) => {
  res.json({ ok: true });
});

app.post("/chat", async (req, res) => {
  try {
    if (!OPENAI_API_KEY) {
      return res.status(500).json({
        error: "Backend belum dikonfigurasi: OPENAI_API_KEY belum diatur."
      });
    }

    const message = typeof req.body?.message === "string"
      ? req.body.message.trim()
      : "";

    if (!message) {
      return res.status(400).json({ error: "Pesan tidak boleh kosong." });
    }

    if (message.length > 4000) {
      return res.status(413).json({ error: "Pesan terlalu panjang (maksimal 4000 karakter)." });
    }

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: OPENAI_MODEL,
        instructions: "Kamu adalah LALL AI, asisten yang ramah, jelas, dan membantu. Jawab dalam bahasa yang digunakan pengguna, kecuali diminta lain.",
        input: message,
        max_output_tokens: 700
      })
    });

    const data = await response.json();

    if (!response.ok) {
      console.error("OpenAI API error:", response.status, data?.error?.code || "unknown");
      return res.status(502).json({
        error: "Layanan AI gagal memproses permintaan. Periksa konfigurasi API dan saldo/limit akun."
      });
    }

    const reply = typeof data.output_text === "string" ? data.output_text.trim() : "";
    if (!reply) {
      return res.status(502).json({ error: "AI tidak mengembalikan teks jawaban." });
    }

    return res.json({ reply });
  } catch (error) {
    console.error("Server error:", error?.message || "unknown");
    return res.status(500).json({ error: "Terjadi kesalahan pada backend." });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`LALL AI backend berjalan di port ${PORT}`);
});
