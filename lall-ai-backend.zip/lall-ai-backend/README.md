# LALL AI Backend

Backend sederhana untuk menghubungkan aplikasi (misalnya Thunkable) ke OpenAI Responses API.

## Endpoint

- `GET /` — status singkat
- `GET /health` — pemeriksaan kesehatan
- `POST /chat` — mengirim pesan ke AI

Contoh body `POST /chat`:
```json
{
  "message": "Jelaskan apa itu tata surya"
}
```

Contoh respons:
```json
{
  "reply": "Tata surya adalah ..."
}
```

## Deploy dari HP Android

1. Buat akun pada layanan hosting Node.js yang tepercaya dan mendukung Node.js 20+.
2. Unggah file proyek ini ke repositori Git pribadi atau impor ZIP jika hosting mendukungnya.
3. Atur build/install command: `npm install`.
4. Atur start command: `npm start`.
5. Tambahkan `OPENAI_API_KEY` melalui menu Environment Variables/Secrets di dashboard hosting.
6. Opsional, set `OPENAI_MODEL` ke model yang tersedia pada akun API kamu.
7. Deploy, lalu buka URL publik yang diberikan hosting. `/health` harus mengembalikan `{"ok":true}`.

Jangan taruh API key di aplikasi Thunkable, HTML, file ZIP publik, atau chat. Simpan hanya sebagai secret/environment variable di server.

## Hubungkan dari Thunkable

Buat Web API component dan atur:
- URL: `https://URL-BACKEND-KAMU/chat`
- Method: `POST`
- Header: `Content-Type: application/json`
- Body JSON: `{"message":"TEKS_PERTANYAAN_PENGGUNA"}`

Ambil field `reply` dari respons JSON untuk ditampilkan pada chat. Nama blok/opsi dapat berbeda sesuai versi Thunkable.

## Catatan

- Penggunaan OpenAI API memerlukan API key dan dapat menimbulkan biaya sesuai penggunaan serta model.
- Batas 20 permintaan per menit berlaku per alamat IP pada endpoint `/chat`; untuk aplikasi publik, tambahkan autentikasi pengguna dan kontrol biaya.
- `ALLOWED_ORIGIN` terutama berguna untuk aplikasi web. CORS bukan mekanisme autentikasi dan tidak melindungi API dari semua penyalahgunaan.
- Endpoint ini menerima satu pesan per permintaan; riwayat percakapan belum disimpan.
